﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerBedsLid
{
    public class FlowerBeds
    {
        public static int CalculateFlowerBeds(int x1m, int y1m, int x2m, int y2m, int x1d, int y1d, int x2d, int y2d)
        {
            // Определяем координаты вершин клумб
            int x1 = Math.Min(x1m, x1d);
            int y1 = Math.Min(y1m, y1d);
            int x2 = Math.Max(x2m, x2d);
            int y2 = Math.Max(y2m, y2d);

            // Вычисляем ширину и высоту объединенной клумбы
            int width = x2 - x1;
            int height = y2 - y1;

            // Если клумбы не пересекаются, возвращаем сумму их площадей
            if (width <= 0 || height <= 0)
            {
                return (x2m - x1m) * (y2m - y1m) + (x2d - x1d) * (y2d - y1d);
            }
            // Иначе возвращаем площадь объединенной клумбы
            else
            {
                return width * height;
            }
        }
    }
}
