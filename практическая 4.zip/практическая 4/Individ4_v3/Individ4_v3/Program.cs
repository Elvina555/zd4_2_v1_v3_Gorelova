﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Individ4_v3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Чтение данных из файла input.txt
            string inputFile = "input.txt";
            if (File.Exists(inputFile))
            {
                string[] lines = File.ReadAllLines("input.txt");
                string[] boys = lines[0].Split(' ');
                string[] girls = lines[1].Split(' ');

                // Преобразование координат в целые числа
                int x1m = int.Parse(boys[0]);
                int y1m = int.Parse(boys[1]);
                int x2m = int.Parse(boys[2]);
                int y2m = int.Parse(boys[3]);

                int x1d = int.Parse(girls[0]);
                int y1d = int.Parse(girls[1]);
                int x2d = int.Parse(girls[2]);
                int y2d = int.Parse(girls[3]);

                // Вычисление площади клумбы мальчиков
                int pboys = Math.Abs(x2m - x1m) * Math.Abs(y2m - y1m);
                // Вычисление площади клумбы девочек
                int pgirls = Math.Abs(x2d - x1d) * Math.Abs(y2d - y1d);

                // Вычисление координат пересечения
                int xrezult1 = Math.Max(Math.Min(x1m, x2m), Math.Min(x1d, x2d));
                int xrezult2 = Math.Min(Math.Max(x1m, x2m), Math.Max(x1d, x2d));
                int yrezult1 = Math.Max(Math.Min(y1m, y2m), Math.Min(y1d, y2d));
                int yrezult2 = Math.Min(Math.Max(y1m, y2m), Math.Max(y1d, y2d));

                // Проверка на пересечение
                int count = 0;
                if (xrezult1 < xrezult2 && yrezult1 < yrezult2)
                {
                    count = (xrezult2 - xrezult1) * (yrezult2 - yrezult1);
                }

                // Общая площадь
                int total_area = pboys + pgirls - count;

                // Запись результата в файл output.txt
                File.WriteAllText("output.txt", total_area.ToString());
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
            Console.ReadKey();
        }
    }
}
