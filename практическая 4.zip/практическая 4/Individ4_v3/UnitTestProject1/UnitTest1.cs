﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FlowerBedsLid;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        //1. Тест проверяет, что клумбы пересекаются
        public void TestFlowerbedsIntersect()
        {
            Assert.AreEqual(225, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 5, 5, 15, 15));
        }
        [TestMethod]
        //2. Тест проверяет, что клумбы не пересекаются
        public void TestFlowerbedsDoNotIntersect()
        {
            Assert.AreEqual(900, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 20, 20, 30, 30));
        }
        [TestMethod]
        //3. Тест проверяет,что клумбы касаются друг друга
        public void TestFlowerbedsTouch()
        {
            Assert.AreEqual(200, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 10, 0, 20, 10));
        }
        [TestMethod]
        //4. Тест проверяет,что площадь одной из клумб равна нулю
        public void TestFlowereQualZero()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 5, 5, 5, 5));
        }
        [TestMethod]
        //5. Тест проверяет,что все координаты клумб равны нулю
        public void TestFlowerAllQualZero()
        {
            Assert.AreEqual(0, FlowerBeds.CalculateFlowerBeds(0, 0, 0, 0, 0, 0, 0, 0));
        }
        [TestMethod]
        //6. Тест проверяет,что координаты клумб одинаковые
        public void TestFlowerSimilar()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 0, 0, 10, 10));
        }
        [TestMethod]
        //7. Тест проверяет,что полностью одна клумба перекрывает другую.
        public void TestFlowerOverLaps()
        {
            Assert.AreEqual(225, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 5, 5, 15, 15));
        }
        [TestMethod]
        //8. Тест проверяет, клумбы с отрицательными координатами.
        public void TestFlowerNegativeCoordinates()
        {
            Assert.AreEqual(225, FlowerBeds.CalculateFlowerBeds(-10, -10, 0, 0, -5, -5, 5, 5));
        }
        [TestMethod]
        //9. Тест проверяет, клумбы с большими значениями
        public void TestFlowerLargeCoordinates()
        {
            Assert.AreEqual(2250000, FlowerBeds.CalculateFlowerBeds(1000, 1000, 2000, 2000, 1500, 1500, 2500, 2500));
        }
        [TestMethod]
        //10. Тест проверяет, клумбы с одной общей точкой
        public void TestFlowerShareOnePoint()
        {
            Assert.AreEqual(400, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 10, 10, 20, 20));
        }

        [TestMethod]
        //11. Тест проверяет, клумбы с одной общей вершиной
        public void TestFlowerHaveOneCommonVertex()
        {
            Assert.AreEqual(200, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 10, 0, 20, 10));
        }
        [TestMethod]
        //12. Тест проверяет, клумбы с двумя общими вершинами
        public void TestFlowerHaveTwoCommonVertices()
        {
            Assert.AreEqual(225, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 5, 5, 15, 15));
        }
        [TestMethod]
        //13. Тест проверяет, клумбы с тремя общими вершинами
        public void TestFlowerHaveThreeCommonVertices()
        {
            Assert.AreEqual(144, FlowerBeds.CalculateFlowerBeds(0, 0, 9, 9, 3, 3, 12, 12));
        }

        [TestMethod]
        //14. Тест проверяет, клумбы со всеми четыремя общими вершинами
        public void TestFlowerHaveAllVerticesInCommon()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 0, 0, 10, 10));
        }
        [TestMethod]
        //15. Тест проверяет, все координаты отрицательные
        public void TestFlowerAllCoordinatesAreNegative()
        {
            Assert.AreEqual(81, FlowerBeds.CalculateFlowerBeds(-9999, -9999, -9999, -9999, -9990, -9990, -9999, -9999));
        }
        [TestMethod]
        //16. Тест проверяет, цветочные клумбы с нулевой шириной или высотой
        public void TestFlowerZeroWidthHeight()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 0, 10, 0, 0, 10, 0));
        }
        [TestMethod]
        // 17. Тест проверяет, что клумбы имеют одинаковую площадь, но разные координаты
        public void TestFlowerDifferentCoordinatesSameArea()
        {
            Assert.AreEqual(121, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 1, 1, 11, 11));
        }
        [TestMethod]
        // 18. Тест проверяет, что одна клумба полностью внутри другой
        public void TestOneFlowerInsideAnother()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 2, 2, 7, 7));
        }
        [TestMethod]
        // 19. Тест проверяет, что клумбы имеют нулевую ширину и высоту, но одна из них не нулевая
        public void TestOneFlowerZeroWidthHeight()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 5, 5, 5, 5));
        }
        [TestMethod]
        // 20. Тест проверяет, что клумбы имеют одинаковый размер, но одна перевернута
        public void TestFlowerTheSameSizeButOneUpsideDown()
        {
            Assert.AreEqual(100, FlowerBeds.CalculateFlowerBeds(0, 0, 10, 10, 10, 10, 0, 0));
        }
    }
}

