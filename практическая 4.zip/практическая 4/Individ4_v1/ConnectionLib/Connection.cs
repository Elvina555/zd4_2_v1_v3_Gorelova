﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectionLib
{
    public class Connection
    {
        public static int Calculate(int n, int a, int b, int k)
        {
            if (k == 0)
            {
                return 0;
            }
            int count = a;
            if (k > 1)
            {
                int minutes = Math.Min(k - 1, n);
                count += minutes * b;
            }

            return count;
        }
    }
}
