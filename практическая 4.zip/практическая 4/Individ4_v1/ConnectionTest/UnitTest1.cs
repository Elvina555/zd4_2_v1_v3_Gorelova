﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ConnectionLib;

namespace ConnectionTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        //1. Тест для проверки нулевого времени, результат будет равен 0, так как нет затрат на соединение.

        public void TestCalculateZeroMinutes()
        {
            Assert.AreEqual(0, Connection.Calculate(5, 2, 3, 0));
        }

        [TestMethod]
        //2. Тест для проверки расчёта за 1 минуту, результат равен начальному значению a, так как нет дополнительных минут для начисления.
        public void TestCalculateOneMinute()
        {
            Assert.AreEqual(2, Connection.Calculate(5, 2, 3, 1));
        }

        [TestMethod]
        //3. Тест для проверки расчёта за 2 минуты, результат равен a + b, где b — стоимость за минуту.
        public void TestCalculateTwoMinutes()
        {
            Assert.AreEqual(5, Connection.Calculate(5, 2, 3, 2));
        }

        [TestMethod]
        //4. Тест для проверки расчёта за 3 минуты, результат равен a + 2 * b, что учитывает две дополнительные минуты.
        public void Test_Calculate_ThreeMinutes()
        {
            Assert.AreEqual(8, Connection.Calculate(5, 2, 3, 3));
        }

        [TestMethod]
        //5. Тест для проверки расчёта за 4 минуты, результат равен a + 3 * b.
        public void TestCalculateFourMinutes()
        {
            Assert.AreEqual(11, Connection.Calculate(5, 2, 3, 4));
        }

        [TestMethod]
        //6. Тест для проверки расчёта за 5 минут, результат равен a + 4 * b.
        public void TestCalculateFiveMinutes()
        {
            Assert.AreEqual(14, Connection.Calculate(5, 2, 3, 5));
        }

        [TestMethod]
        //7. Тест для проверки расчёта за 6 минут,результат равен a + 5 * b, что соответствует максимальному количеству минут.
        public void TestCalculateSixMinutes()
        {
            Assert.AreEqual(17, Connection.Calculate(5, 2, 3, 6));
        }

        [TestMethod]
        //8. Тест для проверки расчёта за 7 минут, результат остаётся равным a + 5 * b, так как n ограничивает количество минут.
        public void TestCalculateSevenMinutes()
        {
            Assert.AreEqual(17, Connection.Calculate(5, 2, 3, 7));
        }

        [TestMethod]
        //9. Тест проверяет, что при большом значении k (например, 100) результат остаётся равным a + 5 * b, так как n ограничивает количество минут.
        public void TestCalculateMaxMinutes()
        {
            Assert.AreEqual(17, Connection.Calculate(5, 2, 3, 100));
        }

        [TestMethod]
        //10. Тест проверяет, что если начальная стоимость соединения равна 0, то результат также будет равен 0, даже если есть минуты.
        public void TestCalculateZeroConnection()
        {
            Assert.AreEqual(0, Connection.Calculate(1, 0, 0, 1));
        }

        [TestMethod]
        //11. Тест проверяет, что если разговор длится 1 минуту, а стоимость соединения a больше 0, то итоговая стоимость равна a
        public void TestCalculateConnectionOne()
        {
            Assert.AreEqual(5, Connection.Calculate(5, 5, 3, 1));
        }

        [TestMethod]
        //12. Тест проверяет, что при 3 минутах и высокой стоимости соединения результат соответствует ожидаемому значению.
        public void TestCalculateConnectionMax()
        {
            Assert.AreEqual(20, Connection.Calculate(5, 10, 5, 3));
        }

        [TestMethod]
        //13. Тест проверяет, что если стоимость в минуту равна 0, то результат будет равен начальному значению a.
        public void TestCalculateConnectionZeroMinute()
        {
            Assert.AreEqual(2, Connection.Calculate(5, 2, 0, 3));
        }

        [TestMethod]
        //14. Тест проверяет, что если стоимость соединения равна 0, то итоговая стоимость 1 минуты разговора также равна 0.
        public void TestCalculateConnectionZero()
        {
            Assert.AreEqual(0, Connection.Calculate(5, 0, 3, 1));
        }

        [TestMethod]
        //15. Тест проверяет, что если минут больше, чем n, то стоимость остаётся равной a + (n-1) * b, так как после n-й минуты разговор бесплатен.
        public void TestCalculateMinutesN()
        {
            Assert.AreEqual(35, Connection.Calculate(10, 10, 5, 6));
        }

        [TestMethod]
        //16. Тест проверяет, что если минут ровно n, то стоимость равна a + (n-1) * b.
        public void TestCalculateN()
        {
            Assert.AreEqual(30, Connection.Calculate(5, 10, 5, 5));
        }

        [TestMethod]
        //17. Тест роверяет, что если пристутствуют отрицательные значения, итоговая стоимость равна 0.
        public void TestCalculateNegativeValues()
        {
            Assert.AreEqual(0, Connection.Calculate(5, -5, -3, 0));
        }

        [TestMethod]
        //18. Тест проверяет, что если стоимость минуты отрицательная, то итоговая стоимость не меняется и равна стоимости соединения a.
        public void TestCalculateNegativeMinute()
        {
            Assert.AreEqual(2, Connection.Calculate(5, 2, -3, 1));
        }

        [TestMethod]
        //19. Тест проверяет, что при больших значениях входных параметров метод корректно рассчитывает итоговую стоимость.
        public void Test_Calculate_LargeValues()
        {
            Assert.AreEqual(199, Connection.Calculate(100, 100, 1, 100));
        }

        [TestMethod]
        //20. Тест проверяет, что метод правильно обрабатывает крайние случаи, когда нет никаких значений для расчёта.
        public void TestCalculateOnlyCost()
        {
            Assert.AreEqual(0, Connection.Calculate(0, 0, 0, 0));
        }

    }
}
