﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Individ4_v1_3_
{
    internal class Program
    {
        //a — стоимость соединения (в рублях).
        //b — стоимость минуты разговора со второй по n-ю (в рублях).
        //n — количество минут, по истечении которых разговор снова становится бесплатным (включительно).
        //k — общее время разговора в минутах(включая бесплатные минуты).
        static int Calculate(int n , int a, int b, int k)
        {
            if (k == 0)// Если разговор не состоялся
            {
                return 0; 
            }
            int count = a;
            if (k > 1)
            {
                // Если разговор длился больше одной минуты
                int minutes = Math.Min(k - 1, n);
                count += minutes * b;
            }

            return count;
        }
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            if (File.Exists(inputFile))
            {
                string[] input = File.ReadAllLines("input.txt");
                string[] parameters = input[0].Split(' ');
                if (parameters.Length != 4)
                {
                    Console.WriteLine("Нужно предоставить 4 параметра.");
                    return;
                }
                int n = int.Parse(parameters[0]);
                int a = int.Parse(parameters[1]);
                int b = int.Parse(parameters[2]);
                int k = int.Parse(parameters[3]);
                // Вычисление стоимости разговора
                int cost = Calculate(n, a, b, k);
                File.WriteAllText("output.txt", cost.ToString());
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
            Console.ReadKey();
        }

        
    }
}
